export const jwtConstants = {
  secret: process.env.JWT_SECRET || 'CHANGE_ME_NOW',
};
