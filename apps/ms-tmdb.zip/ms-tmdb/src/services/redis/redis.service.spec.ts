import { Test, TestingModule } from '@nestjs/testing';
import { RedisService } from './redis.service';
import Redis from 'ioredis';

/**
 * Mock du client Redis retourné par le constructeur Redis()
 * On simule uniquement les méthodes utilisées dans le service
 */
const redisMock = {
  get: jest.fn(),
  set: jest.fn(),
  on: jest.fn(),
};

/**
 * Mock du module ioredis
 * À chaque "new Redis()", on retourne redisMock
 */
jest.mock('ioredis', () => {
  return jest.fn().mockImplementation(() => redisMock);
});

describe('RedisService (tests complets)', () => {
  let service: RedisService;

  beforeEach(async () => {
    // Nettoyage des appels entre chaque test
    jest.clearAllMocks();

    // Création du module de test NestJS
    const module: TestingModule = await Test.createTestingModule({
      providers: [RedisService],
    }).compile();

    // Récupération de l’instance du service
    service = module.get<RedisService>(RedisService);

    // Appel manuel du hook de cycle de vie
    service.onModuleInit();
  });

  /**
   * Vérifie que le service est bien instancié
   */
  it('doit être défini', () => {
    expect(service).toBeDefined();
  });

  /**
   * Vérifie que Redis est bien instancié avec les paramètres par défaut
   */
  it('doit initialiser le client Redis au démarrage', () => {
    expect(Redis).toHaveBeenCalledWith({
      host: 'redis',
      port: 6379,
    });
  });

  /**
   * Vérifie le comportement lors de l’événement "connect"
   */
  it('doit passer valable à true lors de la connexion Redis', () => {
    // Récupération du callback enregistré pour l’événement "connect"
    const connectHandler = redisMock.on.mock.calls.find(
      (call) => call[0] === 'connect',
    )?.[1];

    // Simulation de la connexion Redis
    connectHandler();

    expect((service as any).valable).toBe(true);
  });

  /**
   * Vérifie le comportement lors de l’événement "error"
   */
  it('doit invalider le client lors d’une erreur Redis', () => {
    const errorHandler = redisMock.on.mock.calls.find(
      (call) => call[0] === 'error',
    )?.[1];

    // Simulation d’une erreur Redis
    errorHandler(new Error('Redis indisponible'));

    expect((service as any).valable).toBe(false);
    expect((service as any).redisClient).toBeNull();
  });

  /**
   * Vérifie que get() retourne null si Redis n’est pas disponible
   */
  it('get() doit retourner null si redisClient est null', async () => {
    (service as any).redisClient = null;

    const result = await service.get('key');

    expect(result).toBeNull();
  });

  /**
   * Vérifie que get() retourne une valeur JSON parsée
   */
  it('get() doit retourner la valeur parsée si la clé existe', async () => {
    const value = { id: 42 };

    redisMock.get.mockResolvedValueOnce(JSON.stringify(value));

    const result = await service.get<typeof value>('test-key');

    expect(redisMock.get).toHaveBeenCalledWith('test-key');
    expect(result).toEqual(value);
  });

  /**
   * Vérifie que get() retourne null si la clé n’existe pas
   */
  it('get() doit retourner null si la clé n’existe pas', async () => {
    redisMock.get.mockResolvedValueOnce(null);

    const result = await service.get('unknown-key');

    expect(result).toBeNull();
  });

  /**
   * Vérifie que set() ne fait rien si Redis n’est pas disponible
   */
  it('set() ne doit rien faire si redisClient est null', async () => {
    (service as any).redisClient = null;

    await expect(service.set('key', 'value')).resolves.toBeUndefined();
    expect(redisMock.set).not.toHaveBeenCalled();
  });

  /**
   * Vérifie que set() enregistre bien la valeur avec un TTL
   */
  it('set() doit enregistrer la valeur avec un TTL', async () => {
    const value = { name: 'cache-test' };

    await service.set('cache-key', value, 300);

    expect(redisMock.set).toHaveBeenCalledWith(
      'cache-key',
      JSON.stringify(value),
      'EX',
      300,
    );
  });
});