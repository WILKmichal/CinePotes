import { HttpException } from '@nestjs/common';
import { TmdbController } from './tmdb.controller';
import { TmdbService } from './tmdb.service';

describe('ms-tmdb TmdbController', () => {
  let controller: TmdbController;
  let service: jest.Mocked<TmdbService>;

  beforeEach(() => {
    service = {
      obtenirPlusieursFilms: jest.fn(),
      obtenirFilmsPopulaires: jest.fn(),
      rechercherFilms: jest.fn(),
      rechercherFilmsAvancee: jest.fn(),
      obtenirDetailsFilm: jest.fn(),
    } as any;

    controller = new TmdbController(service);
  });

  it('getMovies: ids required', async () => {
    // @ts-expect-error
    await expect(controller.getMovies(undefined)).rejects.toBeInstanceOf(
      HttpException,
    );
  });

  it('getMovies: ids invalid', async () => {
    await expect(controller.getMovies('a,b')).rejects.toBeInstanceOf(
      HttpException,
    );
  });

  it('getMovies: calls service.obtenirPlusieursFilms', async () => {
    service.obtenirPlusieursFilms.mockResolvedValueOnce([{ id: 1 }] as any);
    const res = await controller.getMovies('1, 2, x');
    expect(res).toEqual([{ id: 1 }]);
    expect(service.obtenirPlusieursFilms).toHaveBeenCalledWith([1, 2]);
  });

  it('getPopularMovies', async () => {
    service.obtenirFilmsPopulaires.mockResolvedValueOnce([{ id: 9 }] as any);
    const res = await controller.getPopularMovies();
    expect(res).toEqual([{ id: 9 }]);
    expect(service.obtenirFilmsPopulaires).toHaveBeenCalled();
  });

  it('rechercherFilms: query min 3', async () => {
    await expect(controller.rechercherFilms('ab')).rejects.toBeInstanceOf(
      HttpException,
    );
  });

  it('rechercherFilms: calls service', async () => {
    service.rechercherFilms.mockResolvedValueOnce([{ id: 3 }] as any);
    const res = await controller.rechercherFilms('batman');
    expect(res).toEqual([{ id: 3 }]);
    expect(service.rechercherFilms).toHaveBeenCalledWith('batman');
  });

  it('rechercherFilmsAvancee: requires at least one filter', async () => {
    await expect(
      controller.rechercherFilmsAvancee(undefined, undefined, undefined),
    ).rejects.toBeInstanceOf(HttpException);
  });

  it('rechercherFilmsAvancee: calls service with trims', async () => {
    service.rechercherFilmsAvancee.mockResolvedValueOnce([{ id: 11 }] as any);

    const res = await controller.rechercherFilmsAvancee(
      '  tit ',
      ' 2019 ',
      ' action ',
    );

    expect(res).toEqual([{ id: 11 }]);
    expect(service.rechercherFilmsAvancee).toHaveBeenCalledWith({
      titre: 'tit',
      annee: '2019',
      genre: 'action',
    });
  });

  it('getMovie: calls service.obtenirDetailsFilm', async () => {
    service.obtenirDetailsFilm.mockResolvedValueOnce({ id: 55 } as any);
    const res = await controller.getMovie(55);
    expect(res).toEqual({ id: 55 });
    expect(service.obtenirDetailsFilm).toHaveBeenCalledWith(55);
  });
});
