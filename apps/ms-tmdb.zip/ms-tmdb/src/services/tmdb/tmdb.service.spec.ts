import { HttpException, HttpStatus } from '@nestjs/common';
import axios from 'axios';
import { TmdbService } from './tmdb.service';
import { RedisService } from '../redis/redis.service';

jest.mock('axios');

describe('ms-tmdb TmdbService', () => {
  let service: TmdbService;
  let redis: jest.Mocked<RedisService>;

  const mockedAxios = axios as jest.Mocked<typeof axios>;

  beforeEach(() => {
    jest.resetAllMocks();
    process.env.TMDB_API_KEY = 'KEY';

    redis = {
      get: jest.fn(),
      set: jest.fn(),
    } as any;

    service = new TmdbService(redis);
  });

  describe('obtenirGenres (via rechercherFilmsAvancee / trouverGenreIdParNom)', () => {
    it('cache hit: يرجّع من redis بلا axios', async () => {
      // نخلي rechercherFilmsAvancee يدير branch ديال titre+genre باش يستعمل genre list
      redis.get.mockResolvedValueOnce(null); // recherche_avancee cache miss
      // obtenirGenres cache hit
      (redis.get as jest.Mock).mockImplementationOnce(async (key: string) => {
        if (key === 'tmdb:genres:movie') return [{ id: 28, name: 'Action' }];
        return null;
      });

      mockedAxios.get.mockResolvedValueOnce({
        data: { results: [{ id: 1, title: 'X', genre_ids: [28] }] },
      } as any);

      const res = await service.rechercherFilmsAvancee({
        titre: 'x',
        genre: 'Action',
      });

      expect(res[0].id).toBe(1);
      expect(mockedAxios.get).toHaveBeenCalled(); // search/movie
    });

    it('cache miss: axios genre list + redis.set', async () => {
      // for obtenirGenres directly via private call access
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockResolvedValueOnce({
        data: { genres: [{ id: 12, name: 'Adventure' }] },
      } as any);

      const genres = await (service as any).obtenirGenres();
      expect(genres).toEqual([{ id: 12, name: 'Adventure' }]);
      expect(redis.set).toHaveBeenCalledWith('tmdb:genres:movie', genres, 86400);
    });
  });

  describe('obtenirDetailsFilm', () => {
    it('cache hit: يرجّع من redis', async () => {
      redis.get.mockResolvedValueOnce({ id: 10 } as any);

      const res = await service.obtenirDetailsFilm(10);
      expect(res).toEqual({ id: 10 });
      expect(mockedAxios.get).not.toHaveBeenCalled();
    });

    it('cache miss: axios + set + poster mapping', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockResolvedValueOnce({
        data: {
          id: 5,
          title: 'Film',
          overview: null,
          release_date: '2020-01-01',
          poster_path: '/p.png',
          vote_average: 7.5,
        },
      } as any);

      const res = await service.obtenirDetailsFilm(5);

      expect(res).toEqual({
        id: 5,
        titre: 'Film',
        resume: '',
        date_sortie: '2020-01-01',
        affiche_url: 'https://image.tmdb.org/t/p/w500/p.png',
        note_moyenne: 7.5,
      });

      expect(redis.set).toHaveBeenCalledWith('tmdb:film:5', res, 7200);
    });

    it('handleTmdbError: 404 -> NOT_FOUND', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockRejectedValueOnce({
        response: { status: 404, data: { status_message: 'Not found' } },
        isAxiosError: true,
      } as any);

      await expect(service.obtenirDetailsFilm(999)).rejects.toMatchObject({
        status: HttpStatus.NOT_FOUND,
      });
    });

    it('handleTmdbError: 401 -> UNAUTHORIZED', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockRejectedValueOnce({
        response: { status: 401, data: { status_message: 'Invalid key' } },
        isAxiosError: true,
      } as any);

      await expect(service.obtenirDetailsFilm(1)).rejects.toMatchObject({
        status: HttpStatus.UNAUTHORIZED,
      });
    });

    it('handleTmdbError: 429 -> TOO_MANY_REQUESTS', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockRejectedValueOnce({
        response: { status: 429, data: { status_message: 'Rate limit' } },
        isAxiosError: true,
      } as any);

      await expect(service.obtenirDetailsFilm(1)).rejects.toMatchObject({
        status: HttpStatus.TOO_MANY_REQUESTS,
      });
    });

    it('handleTmdbError: other axios status -> keeps status/message', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockRejectedValueOnce({
        response: { status: 503, data: { status_message: 'Service down' } },
        isAxiosError: true,
      } as any);

      await expect(service.obtenirDetailsFilm(1)).rejects.toMatchObject({
        status: 503,
      });
    });

    it('unknown error -> 500', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockRejectedValueOnce(new Error('weird'));

      await expect(service.obtenirDetailsFilm(1)).rejects.toMatchObject({
        status: 500,
      });
    });
  });

  describe('obtenirPlusieursFilms', () => {
    it('calls obtenirDetailsFilm for each id', async () => {
      const spy = jest
        .spyOn(service, 'obtenirDetailsFilm')
        .mockImplementation(async (id: number) => ({ id } as any));

      const res = await service.obtenirPlusieursFilms([1, 2, 3]);
      expect(res.map((x) => x.id)).toEqual([1, 2, 3]);
      expect(spy).toHaveBeenCalledTimes(3);
    });
  });

  describe('obtenirFilmsPopulaires', () => {
    it('cache hit', async () => {
      redis.get.mockResolvedValueOnce([{ id: 1 }] as any);
      const res = await service.obtenirFilmsPopulaires();
      expect(res).toEqual([{ id: 1 }]);
      expect(mockedAxios.get).not.toHaveBeenCalled();
    });

    it('cache miss: axios popular + mapping + set', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockResolvedValueOnce({
        data: {
          results: [
            {
              id: 1,
              title: 'A',
              overview: 'O',
              release_date: '2020',
              poster_path: null,
              vote_average: null,
            },
          ],
        },
      } as any);

      const res = await service.obtenirFilmsPopulaires();
      expect(res[0]).toMatchObject({
        id: 1,
        titre: 'A',
        resume: 'O',
        affiche_url: null,
        note_moyenne: 0,
      });
      expect(redis.set).toHaveBeenCalledWith('tmdb:films:populaires', res, 7200);
    });
  });

  describe('rechercherFilms', () => {
    it('cache hit', async () => {
      redis.get.mockResolvedValueOnce([{ id: 2 }] as any);
      const res = await service.rechercherFilms('X');
      expect(res).toEqual([{ id: 2 }]);
      expect(mockedAxios.get).not.toHaveBeenCalled();
    });

    it('cache miss: axios search + set', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockResolvedValueOnce({
        data: { results: [{ id: 9, title: 'T' }] },
      } as any);

      const res = await service.rechercherFilms('Term');
      expect(res[0].id).toBe(9);
      expect(redis.set).toHaveBeenCalled();
    });
  });

  describe('rechercherFilmsAvancee', () => {
    it('cache hit', async () => {
      redis.get.mockResolvedValueOnce([{ id: 77 }] as any);
      const res = await service.rechercherFilmsAvancee({ titre: 'x' });
      expect(res).toEqual([{ id: 77 }]);
      expect(mockedAxios.get).not.toHaveBeenCalled();
    });

    it('branch 1: titre موجود -> search/movie + optional genre filter OK', async () => {
      redis.get.mockResolvedValueOnce(null); // recherche_avancee cache miss
      // obtenirGenres cache miss
      (redis.get as jest.Mock).mockImplementationOnce(async (key: string) => {
        if (key === 'tmdb:genres:movie') return null;
        return null;
      });

      // axios #1: genre list
      mockedAxios.get
        .mockResolvedValueOnce({
          data: { genres: [{ id: 28, name: 'Action' }] },
        } as any)
        // axios #2: search/movie
        .mockResolvedValueOnce({
          data: {
            results: [
              { id: 1, title: 'A', genre_ids: [28] },
              { id: 2, title: 'B', genre_ids: [12] },
            ],
          },
        } as any);

      const res = await service.rechercherFilmsAvancee({
        titre: 'abc',
        annee: '2019',
        genre: 'Action',
      });

      expect(res.map((x) => x.id)).toEqual([1]);
      expect(redis.set).toHaveBeenCalled(); // caches result
    });

    it('titre + genre but genre name not found -> returns [] and cache 600', async () => {
      redis.get.mockResolvedValueOnce(null); // recherche_avancee cache miss
      // obtenirGenres returns list without requested genre
      (redis.get as jest.Mock).mockImplementationOnce(async (key: string) => {
        if (key === 'tmdb:genres:movie') return [{ id: 1, name: 'Comedy' }];
        return null;
      });

      mockedAxios.get.mockResolvedValueOnce({
        data: { results: [{ id: 10, title: 'X', genre_ids: [28] }] },
      } as any);

      const res = await service.rechercherFilmsAvancee({
        titre: 'x',
        genre: 'Action',
      });

      expect(res).toEqual([]);
      expect(redis.set).toHaveBeenCalledWith(expect.any(String), [], 600);
    });

    it('branch 2: no titre -> discover/movie with annee only', async () => {
      redis.get.mockResolvedValueOnce(null);

      mockedAxios.get.mockResolvedValueOnce({
        data: { results: [{ id: 5, title: 'D' }] },
      } as any);

      const res = await service.rechercherFilmsAvancee({ annee: '2020' });
      expect(res[0].id).toBe(5);
      expect(mockedAxios.get).toHaveBeenCalledWith(
        expect.stringContaining('/discover/movie'),
        expect.objectContaining({
          params: expect.objectContaining({ primary_release_year: '2020' }),
        }),
      );
    });

    it('branch 2: no titre + genre not found -> [] + cache 600', async () => {
      redis.get.mockResolvedValueOnce(null);

      // obtenirGenres returns list without requested genre
      (redis.get as jest.Mock).mockImplementationOnce(async (key: string) => {
        if (key === 'tmdb:genres:movie') return [{ id: 1, name: 'Comedy' }];
        return null;
      });

      const res = await service.rechercherFilmsAvancee({ genre: 'Action' });

      expect(res).toEqual([]);
      expect(redis.set).toHaveBeenCalledWith(expect.any(String), [], 600);
      expect(mockedAxios.get).not.toHaveBeenCalled();
    });

    it('branch 2: no titre + genre found -> discover/movie with with_genres', async () => {
      redis.get.mockResolvedValueOnce(null);

      // obtenirGenres cache hit
      (redis.get as jest.Mock).mockImplementationOnce(async (key: string) => {
        if (key === 'tmdb:genres:movie') return [{ id: 28, name: 'Action' }];
        return null;
      });

      mockedAxios.get.mockResolvedValueOnce({
        data: { results: [{ id: 8, title: 'Z' }] },
      } as any);

      const res = await service.rechercherFilmsAvancee({ genre: 'Action' });
      expect(res[0].id).toBe(8);

      expect(mockedAxios.get).toHaveBeenCalledWith(
        expect.stringContaining('/discover/movie'),
        expect.objectContaining({
          params: expect.objectContaining({ with_genres: 28 }),
        }),
      );
    });
  });
});