import { Test } from '@nestjs/testing';
import { INestApplication, HttpStatus } from '@nestjs/common';
import request from 'supertest';
import axios from 'axios';

import { TmdbModule } from './tmdb.module';
import { RedisService } from '../redis/redis.service';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('TMDB API (e2e)', () => {
  let app: INestApplication;

  const redisMock = {
    get: jest.fn(),
    set: jest.fn(),
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({
      imports: [TmdbModule],
    })
      .overrideProvider(RedisService)
      .useValue(redisMock)
      .compile();

    app = moduleRef.createNestApplication();
    await app.init();
  });

  beforeEach(() => jest.clearAllMocks());
  afterAll(async () => app.close());

  it('GET /tmdb/films/populaires → 200', async () => {
    redisMock.get.mockResolvedValue(null);

    mockedAxios.get.mockResolvedValue({
      data: {
        results: [
          {
            id: 1,
            title: 'Pop',
            overview: 'Desc',
            release_date: '2020-01-01',
            poster_path: '/p.jpg',
            vote_average: 7,
          },
        ],
      },
    } as any);

    const res = await request(app.getHttpServer())
      .get('/tmdb/films/populaires')
      .expect(HttpStatus.OK);

    expect(res.body[0]).toHaveProperty('titre', 'Pop');
  });

  it('GET /tmdb/recherche query invalide → 400', async () => {
    await request(app.getHttpServer())
      .get('/tmdb/recherche?query=a')
      .expect(HttpStatus.BAD_REQUEST);
  });

  it('GET /tmdb/movies sans ids → 400', async () => {
    await request(app.getHttpServer())
      .get('/tmdb/movies')
      .expect(HttpStatus.BAD_REQUEST);
  });

  it('GET /tmdb/:id invalide → 400', async () => {
    await request(app.getHttpServer())
      .get('/tmdb/abc')
      .expect(HttpStatus.BAD_REQUEST);
  });
});
